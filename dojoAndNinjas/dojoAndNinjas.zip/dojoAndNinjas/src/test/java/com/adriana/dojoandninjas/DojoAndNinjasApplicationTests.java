package com.adriana.dojoandninjas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojoAndNinjasApplicationTests {

	@Test
	void contextLoads() {
	}

}
